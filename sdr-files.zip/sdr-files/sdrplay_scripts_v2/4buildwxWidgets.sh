#!/bin//bash
sudo apt-get install git build-essential automake cmake libhamlib-dev \
libpulse-dev freeglut*-dev libgtk-3-dev libgtk2.0-dev --fix-missing -y
mkdir -p ~/Dev/wxWidgets
cd ~/Dev/wxWidgets
wget https://github.com/wxWidgets/wxWidgets/releases/download/v3.2.4/wxWidgets-3.2.4.tar.bz2
tar -xvjf wxWidgets-3.2.4.tar.bz2  
cd wxWidgets-3.2.4/
mkdir -p ~/Dev/wxWidgets-staticlib

./autogen.sh 
./configure --prefix=`echo ~/Dev/wxWidgets-staticlib` --with-opengl --disable-glcanvasegl \
--disable-shared --enable-monolithic --with-libjpeg --with-libtiff \
--with-libpng --with-zlib --disable-sdltest --enable-unicode --enable-display \
--enable-propgrid --disable-webview --disable-webviewwebkit CXXFLAGS="-std=c++0x"
make -j4 && make install
