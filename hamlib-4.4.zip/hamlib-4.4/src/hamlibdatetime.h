/* This date time is from the last non-merge commit to Hamlib. */
#define HAMLIBDATETIME "Thu Dec 02 23:46:51 2021 +0000 SHA=5f8c4c"
