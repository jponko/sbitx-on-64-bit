export CXXFLAGS='-O2 -march=native -mtune=native'
export CFLAGS='-O2 -march=native -mtune=native'
sudo apt-get update
sudo apt-get install libfltk1.3-dev
sudo apt-get install -y libjpeg62-turbo-dev
sudo apt-get install libjpeg9-dev
sudo apt-get install libxft-dev
sudo apt-get install libxinerama-dev
sudo apt-get install libxcursor-dev
sudo apt-get install libsndfile1-dev
sudo apt-get install libsamplerate0-dev
sudo apt-get install portaudio19-dev
sudo apt-get install libusb-1.0-0-dev
sudo apt-get install libpulse-dev
sudo apt-get install libudev-dev
sudo apt-get install texinfo
